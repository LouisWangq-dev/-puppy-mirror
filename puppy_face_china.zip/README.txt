Puppy Mirror 中国访问轻量版

1. index.html 是整个网页。
2. 朋友不需要 Python。
3. 正式通过网址使用摄像头时，托管服务必须提供 HTTPS。
4. 这一版没有 Google、MediaPipe、CDN 或外部 AI 模型依赖。
5. 支持 FaceDetector 的浏览器会显示绿色人脸框；其他浏览器自动进入轻量互动模式。
